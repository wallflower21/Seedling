package com.kjs.seedling;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class info extends AppCompatActivity {
    ListView list;
    String[] plant = {
            "Maize",
            "Scentless Mayweed",
            "Cleavers",
            "Common Chickweed",
            "Loose Silky-bent",
            "Charlock",
            "Fat Hen",
            "Common Wheat",
            "Black Grass",
            "Sugar beet",
            "Small flowered cranes bill",
            "Shepherds Purse"

    } ;
    Integer[] imageId = {
            R.drawable.maize,
            R.drawable.scentless_mayweed,
            R.drawable.cleavers_seedling,
            R.drawable.common_chickweed,
            R.drawable.loose_silky_bent,
            R.drawable.charlock,
            R.drawable.fathen,
            R.drawable.commonwheat,
            R.drawable.blackgrass,
            R.drawable.sugarbeet,
            R.drawable.cranesbill,
            R.drawable.shepherds_purse

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        CustomList adapter = new
                CustomList(this, plant, imageId);
        list = (ListView) findViewById(R.id.list);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), maize.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 1) {
                    Intent myIntent = new Intent(view.getContext(), Scentless_mayweed.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 2) {
                    Intent myIntent = new Intent(view.getContext(), Cleavers_seedling.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 3) {
                    Intent myIntent = new Intent(view.getContext(), Common_chickweed.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 4) {
                    Intent myIntent = new Intent(view.getContext(), Loose_silky_bent.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 5) {
                    Intent myIntent = new Intent(view.getContext(), Charlock.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 6) {
                    Intent myIntent = new Intent(view.getContext(), Fathen.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 7) {
                    Intent myIntent = new Intent(view.getContext(), wheat.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 8) {
                    Intent myIntent = new Intent(view.getContext(), Blackgrass.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 9) {
                    Intent myIntent = new Intent(view.getContext(), Sugarbeet.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 10) {
                    Intent myIntent = new Intent(view.getContext(), Cranesbill.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 11) {
                    Intent myIntent = new Intent(view.getContext(), Shepherdspurse.class);
                    startActivityForResult(myIntent, 0);
                }
            }
            });





    }
}