package com.kjs.seedling;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Common_chickweed extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common_chickweed);
    }
}
