package com.kjs.seedling;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class post_login extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    public ImageButton plant,wheather,info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_login);
        Toolbar toolbar = findViewById(R.id.toolbar);
        ImageView wheather=findViewById(R.id.weather);
        ImageView info=findViewById(R.id.info);
        ImageView plant=findViewById(R.id.plant);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


         wheather.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 openwheatheract();
             }
         });
         plant.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 openplantact();
             }
         });
         info.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 openinfoact();
             }
         });


    }
    public void openplantact(){
        Intent p=new Intent(this,plant.class);
        startActivity(p);
    }

    public void openinfoact(){
        Intent in=new Intent(this,info.class);
        startActivity(in);
    }

    public void openwheatheract(){
        Intent w=new Intent(this,wheather.class);
        startActivity(w);
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){

            case R.id.nav_about:
                openAbout();
                break;

            case R.id.nav_share:
                openShare();
                break;
            case R.id.nav_rate:
                Toast.makeText(this,"Rate us",Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_contact:
                Toast.makeText(this,"mail",Toast.LENGTH_SHORT).show();
                break;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public void openAbout(){
        Intent about=new Intent(this,about.class);
        startActivity(about);
    }

    public void openShare(){
        Intent share=new Intent(this,share.class);
        startActivity(share);
    }
}
